"""
"""

pizzas = ['Pipironi', 'Margarita', 'Shkol"naya']

for pizza in pizzas:
    print(f"I like {pizza}, pizza!")

